---
title: Nginx和Apache安装与基础部署
date: 2023-11-25 19:29:15
categories: 
  - linux
tags:
    - 运维
    - 服务器
---
### Nginx和Apache安装与基础部署
##### 一：安装
安装方式有多种，每种方式的繁琐程度不同

使用系统包管理器安装 使用源码编译安装 其中，使用系统包管理器安装如沐春风，使用源码编译安装味同嚼蜡。所以我只说用系统包管理器安装

###### 1、使用系统包管理器安装
CentOS系统
```bash
yum install epel-release
yum install nginx
```
Ubuntu系统
```bash
sudo apt update
sudo apt-get install nginx
```
查看版本以确定是否安装成功
```bash
nginx -v
```

启动 nginx

```bash
sudo systemctl start nginx
```

###### 2、一些默认路径
Nginx的网站文件存放在/etc/nginx/sites-available目录下， 默认的静态网页文件夹是/usr/share/nginx/html目录 配置文件通常位于/etc/nginx目录下。具体的文件名可能是nginx.conf 查看Nginx的错误日志，通常位于 /var/log/nginx/error.log

###### 3、设置html文件夹权限
直接用sftp上传文件到linux的html文件下 ，会报权限拒绝

可以先给html赋777权限，然后重启Linux
```bash
// 赋777权限
sudo chmod -R 777 /usr/share/nginx/html

// 重启
sudo service nginx reload
```
卸载nginx(purge参数是指删除删除安装包)
```bash
sudo apt --purge remove nginx
```

##### 二：配置
###### 1、隐藏某级路径
如果你想将静态网页放在nginx的html的dist文件夹下，并希望在URL的某个端口号后不需要写dist就可以打开页面，你可以尝试使用rewrite规则来实现。如果你希望在不同的端口号上对应不同的文件夹，可以在nginx的配置文件中添加多个server块，每个块指定不同的端口号和对应的文件夹路径。以下是一个示例配置：
```nginx
server {
  listen 8080;
  root /path/to/nginx/html/dist1;
  index index.html;
  location / {
    try_files $uri $uri/ /index.html;
  }
}

server {
  listen 8081;
  root /path/to/nginx/html/dist2;
  index index.html;
  location / {
    try_files $uri $uri/ /index.html;
  }
}
```
其中的$uri是指匹配的正则路径，后面的index.html则是使用的文件（即访问$uri时，实际需要访问的文件）
###### 2、设置post请求代理
要在Nginx中配置静态网页的POST请求代理，你可以使用proxy_pass指令来将POST请求反向代理到另一个服务器或应用程序。其实就是在上面配置的server模块中，再加一个location。

以下是一个示例配置：
```nginx
server {
  listen 80;
  server_name example.com;
  location / {
    root /path/to/your/static/files;
    try_files $uri $uri/ =404;
  }
  location /api {
    rewrite ^/api(.*)$ $1 break;
    proxy_pass http://backend_server;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
  }
}
```
上面示例中，在location /api块中添加了一个rewrite指令。这个指令会把请求URL中的/api前缀去掉，并把剩余部分作为反向代理的路径。

这样，如果你的静态网站中的POST请求以/api开头，Nginx将会代理这些请求至后端服务器，并将响应返回给客户端。URL中的/api前缀将被移除，后端服务器收到的请求将是不带前缀的形式。

代理转发后的效果如下：
```
// 浏览器看到的请求
http://39.104.22.73/api/getarticlenum/foreend

// 代理后实际的请求；
http://39.104.22.73:8888/getarticlenum/foreend
```